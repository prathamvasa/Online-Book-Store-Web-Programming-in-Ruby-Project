require 'test_helper'

class ProductsHelperTest < ActionView::TestCase
end
