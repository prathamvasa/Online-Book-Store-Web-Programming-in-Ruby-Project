require 'test_helper'

class ShopperHelperTest < ActionView::TestCase
end
